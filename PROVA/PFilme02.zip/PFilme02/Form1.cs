﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double aux;
            double sum = 0;
            double [,] notas = new double[2,2];
            double[] medias = new double[2];

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    if (!double.TryParse(Interaction.InputBox($"Digite as Notas da pessoa {i+1} para o filme {j+1}", "Entrada de Dados"), out aux))
                    {
                        MessageBox.Show("Entrada inválida");
                        j--;
                        continue;
                    }
                    if (aux >= 0 && aux <= 10)
                    {
                        notas[i, j] = aux;
                        sum += notas[i, j];
                    }
                    else
                    {
                        MessageBox.Show("A nota deve estar entre 0 e 10");
                        j--;
                    }

                }
                medias[i] = sum / 2;
                sum = 0;
            }
            lstboxNotasFilme.Items.Add($"Pessoa 1:  Nota filme 1: {notas[0, 0].ToString("F2")}  Nota filme 2: {notas[0, 1].ToString("F2")}");
            lstboxNotasFilme.Items.Add($"Pessoa 2:  Nota filme 1: {notas[1, 0].ToString("F2")}  Nota filme 2: {notas[1, 1].ToString("F2")}");
            for (int i = 0; i < notas.GetLength(0); i++)
            {
                lstboxNotasFilme.Items.Add($"Média filme {i+1}: {medias[i].ToString("F2")}");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstboxNotasFilme.Items.Clear();
        }
    }
}
