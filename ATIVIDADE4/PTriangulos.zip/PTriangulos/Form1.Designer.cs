﻿namespace PTriangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLado1 = new System.Windows.Forms.MaskedTextBox();
            this.txtLado2 = new System.Windows.Forms.MaskedTextBox();
            this.txtLado3 = new System.Windows.Forms.MaskedTextBox();
            this.lblLado1 = new System.Windows.Forms.Label();
            this.lblLado3 = new System.Windows.Forms.Label();
            this.lbLado2 = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtLado1
            // 
            this.txtLado1.Location = new System.Drawing.Point(112, 79);
            this.txtLado1.Mask = "000.00";
            this.txtLado1.Name = "txtLado1";
            this.txtLado1.Size = new System.Drawing.Size(128, 26);
            this.txtLado1.TabIndex = 0;
            // 
            // txtLado2
            // 
            this.txtLado2.Location = new System.Drawing.Point(112, 164);
            this.txtLado2.Mask = "000.00";
            this.txtLado2.Name = "txtLado2";
            this.txtLado2.Size = new System.Drawing.Size(128, 26);
            this.txtLado2.TabIndex = 1;
            // 
            // txtLado3
            // 
            this.txtLado3.Location = new System.Drawing.Point(112, 247);
            this.txtLado3.Mask = "000.00";
            this.txtLado3.Name = "txtLado3";
            this.txtLado3.Size = new System.Drawing.Size(128, 26);
            this.txtLado3.TabIndex = 2;
            // 
            // lblLado1
            // 
            this.lblLado1.AutoSize = true;
            this.lblLado1.Location = new System.Drawing.Point(31, 82);
            this.lblLado1.Name = "lblLado1";
            this.lblLado1.Size = new System.Drawing.Size(58, 20);
            this.lblLado1.TabIndex = 3;
            this.lblLado1.Text = "Lado 1";
            // 
            // lblLado3
            // 
            this.lblLado3.AutoSize = true;
            this.lblLado3.Location = new System.Drawing.Point(31, 250);
            this.lblLado3.Name = "lblLado3";
            this.lblLado3.Size = new System.Drawing.Size(58, 20);
            this.lblLado3.TabIndex = 4;
            this.lblLado3.Text = "Lado 3";
            // 
            // lbLado2
            // 
            this.lbLado2.AutoSize = true;
            this.lbLado2.Location = new System.Drawing.Point(31, 167);
            this.lbLado2.Name = "lbLado2";
            this.lbLado2.Size = new System.Drawing.Size(58, 20);
            this.lbLado2.TabIndex = 5;
            this.lbLado2.Text = "Lado 2";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(31, 31);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(148, 20);
            this.lblTitulo.TabIndex = 6;
            this.lblTitulo.Text = "Teste seu triângulo:";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(112, 324);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(126, 41);
            this.btnVerificar.TabIndex = 7;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(408, 164);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(164, 26);
            this.txtResultado.TabIndex = 8;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(278, 167);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(124, 20);
            this.lblResultado.TabIndex = 9;
            this.lblResultado.Text = "Seu triângulo é: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lbLado2);
            this.Controls.Add(this.lblLado3);
            this.Controls.Add(this.lblLado1);
            this.Controls.Add(this.txtLado3);
            this.Controls.Add(this.txtLado2);
            this.Controls.Add(this.txtLado1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox txtLado1;
        private System.Windows.Forms.MaskedTextBox txtLado2;
        private System.Windows.Forms.MaskedTextBox txtLado3;
        private System.Windows.Forms.Label lblLado1;
        private System.Windows.Forms.Label lblLado3;
        private System.Windows.Forms.Label lbLado2;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblResultado;
    }
}

