﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.btnCaracterEmBranco = new System.Windows.Forms.Button();
            this.btnContaNumero = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(211, 12);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(366, 299);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Location = new System.Drawing.Point(490, 340);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(168, 59);
            this.btnContaLetra.TabIndex = 9;
            this.btnContaLetra.Text = "Contar Letras";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.btnContaLetra_Click);
            // 
            // btnCaracterEmBranco
            // 
            this.btnCaracterEmBranco.Location = new System.Drawing.Point(301, 340);
            this.btnCaracterEmBranco.Name = "btnCaracterEmBranco";
            this.btnCaracterEmBranco.Size = new System.Drawing.Size(168, 59);
            this.btnCaracterEmBranco.TabIndex = 8;
            this.btnCaracterEmBranco.Text = "Posição Primerio Caracter em branco";
            this.btnCaracterEmBranco.UseVisualStyleBackColor = true;
            this.btnCaracterEmBranco.Click += new System.EventHandler(this.btnCaracterEmBranco_Click);
            // 
            // btnContaNumero
            // 
            this.btnContaNumero.Location = new System.Drawing.Point(115, 340);
            this.btnContaNumero.Name = "btnContaNumero";
            this.btnContaNumero.Size = new System.Drawing.Size(168, 59);
            this.btnContaNumero.TabIndex = 7;
            this.btnContaNumero.Text = "Contar Numeros";
            this.btnContaNumero.UseVisualStyleBackColor = true;
            this.btnContaNumero.Click += new System.EventHandler(this.btnContaNumero_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.btnCaracterEmBranco);
            this.Controls.Add(this.btnContaNumero);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContaLetra;
        private System.Windows.Forms.Button btnCaracterEmBranco;
        private System.Windows.Forms.Button btnContaNumero;
    }
}