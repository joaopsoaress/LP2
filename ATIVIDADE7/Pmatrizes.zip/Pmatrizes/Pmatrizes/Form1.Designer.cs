﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExercicio1 = new System.Windows.Forms.Button();
            this.btnExercicio2 = new System.Windows.Forms.Button();
            this.btnExercicio3 = new System.Windows.Forms.Button();
            this.tnExercicio4 = new System.Windows.Forms.Button();
            this.btnEx5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExercicio1
            // 
            this.btnExercicio1.Location = new System.Drawing.Point(301, 79);
            this.btnExercicio1.Name = "btnExercicio1";
            this.btnExercicio1.Size = new System.Drawing.Size(135, 130);
            this.btnExercicio1.TabIndex = 0;
            this.btnExercicio1.Text = "Exercício 1";
            this.btnExercicio1.UseVisualStyleBackColor = true;
            this.btnExercicio1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnExercicio2
            // 
            this.btnExercicio2.Location = new System.Drawing.Point(500, 79);
            this.btnExercicio2.Name = "btnExercicio2";
            this.btnExercicio2.Size = new System.Drawing.Size(129, 130);
            this.btnExercicio2.TabIndex = 1;
            this.btnExercicio2.Text = "Exercício 2";
            this.btnExercicio2.UseVisualStyleBackColor = true;
            this.btnExercicio2.Click += new System.EventHandler(this.btnExercicio2_Click);
            // 
            // btnExercicio3
            // 
            this.btnExercicio3.Location = new System.Drawing.Point(301, 226);
            this.btnExercicio3.Name = "btnExercicio3";
            this.btnExercicio3.Size = new System.Drawing.Size(135, 126);
            this.btnExercicio3.TabIndex = 2;
            this.btnExercicio3.Text = "Exercício 3";
            this.btnExercicio3.UseVisualStyleBackColor = true;
            this.btnExercicio3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tnExercicio4
            // 
            this.tnExercicio4.Location = new System.Drawing.Point(500, 226);
            this.tnExercicio4.Name = "tnExercicio4";
            this.tnExercicio4.Size = new System.Drawing.Size(129, 130);
            this.tnExercicio4.TabIndex = 3;
            this.tnExercicio4.Text = "Exercício 4";
            this.tnExercicio4.UseVisualStyleBackColor = true;
            this.tnExercicio4.Click += new System.EventHandler(this.tnExercicio4_Click);
            // 
            // btnEx5
            // 
            this.btnEx5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEx5.Location = new System.Drawing.Point(370, 395);
            this.btnEx5.Name = "btnEx5";
            this.btnEx5.Size = new System.Drawing.Size(213, 116);
            this.btnEx5.TabIndex = 4;
            this.btnEx5.Text = "Exercício 5";
            this.btnEx5.UseVisualStyleBackColor = false;
            this.btnEx5.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 613);
            this.Controls.Add(this.btnEx5);
            this.Controls.Add(this.tnExercicio4);
            this.Controls.Add(this.btnExercicio3);
            this.Controls.Add(this.btnExercicio2);
            this.Controls.Add(this.btnExercicio1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExercicio1;
        private System.Windows.Forms.Button btnExercicio2;
        private System.Windows.Forms.Button btnExercicio3;
        private System.Windows.Forms.Button tnExercicio4;
        private System.Windows.Forms.Button btnEx5;
    }
}

