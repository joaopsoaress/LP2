﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            string[] nomes = new string[10];
            int[] qtdChar = new int[10];

            for(int i = 0; i < 10; i++)
            {
               nomes[i] = Interaction.InputBox($"Digite o {i + 1} nome", "Entrada de Dados");
               qtdChar[i] = nomes[i].Replace(" ", "").Length;
               listBox.Items.Add($"nome: {nomes[i]}, qtd: {qtdChar[i]}");
            }

        }
    }
}
